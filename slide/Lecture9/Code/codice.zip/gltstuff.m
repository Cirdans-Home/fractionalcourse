%% Asymptotic distribution for Fractional Differential Equation

alpha = 1.5; N = 100; hN = 1/(N-1);  x = 0:hN:1; dt = hN; 
theta = -pi:2*pi/(N-1):pi;
%dplus = @(x,t) ones(size(x));
%dminus = @(x,t) ones(size(x));
%dplus = @(x,t) cos(pi*x); %
%dminus = @(x,t) cos(pi*x.^2); %
dplus = @(x) gamma(3-alpha).*x.^alpha;
dminus = @(x) gamma(3-alpha).*(1-x).^alpha;
%% Discretize
G = glmatrix(N,alpha);
Gr = G; Grt = G.';
Dplus = diag(dplus(x));
Dminus = diag(dminus(x));
I = eye(N,N);
% Left-hand side
nu = hN^alpha/dt;
A = -(Dplus*Gr + Dminus*Grt);
f = @(theta) -exp(-1i*theta).*(1-exp(1i*theta)).^alpha;
[X,THETA] = meshgrid(x,theta);
h = @(x,theta) nu - (dminus(x).*f(theta) ...
    + dplus(x).*f(-theta));
sv = svd(full(A));
figure(1)
subplot(1,3,1)
plot(theta,sort(abs(f(theta) + f(-theta)),'descend'),'r-',...
    theta,svd(Gr+Grt),'bo',...
    'LineWidth',2)
axis("tight")
legend('|f(\theta)+f(-\theta)','\sigma_j(G_n + G_n^T)')
subplot(1,3,2)
semilogy(x,sort(abs(dminus(x)),'descend'),"r-",x,svd(Dminus),'ro',...
    x,sort(abs(dplus(x)),'descend'),"b-",x,svd(Dplus),'bx',...
    'LineWidth',2)
subplot(1,3,3)
VAL = abs(h(X,THETA));
plot(x,sort(VAL(:,N),'descend'),'r-',...
    x,sort(sv,'descend'),'bo','LineWidth',2);
figure(2)
mesh(X,THETA,abs(h(X,THETA)))
